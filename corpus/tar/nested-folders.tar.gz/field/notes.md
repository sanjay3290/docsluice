# Field notes

Plot B was flooded.
